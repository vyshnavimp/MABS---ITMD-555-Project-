package com.example.mabs;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;



public class BookingActivity extends AppCompatActivity implements OnMapReadyCallback {

    private CheckBox checkBox1, checkBox2, checkBox3;
    private CalendarView calView;
    private RecyclerView tslotView;
    private Button confirmBtn;
    private GoogleMap pMap;
    private TextView selectedLocationText;
    private SupportMapFragment mapFragment;
    private FusedLocationProviderClient locationClient;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 101;
    private static final String TAG = "BookingActivity";

    private String selectedDate;

    private String selectedTimeSlot;

    private String selectedLocationName;
    private String selectedPlaceId;

    private List<String> selectedServices = new ArrayList<>();
    private LatLng selectedLocationLatLng;

    private TextView totalPriceTextView;
    private int totalPrice = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        // Initialize total price
        totalPriceTextView = findViewById(R.id.labelPrice);

        // Initialize CheckBoxes
        checkBox1 = findViewById(R.id.checkBox1);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);
        // Retrieve from intent
        Intent intent = getIntent();
        boolean isGCSelected = intent.getBooleanExtra("General Consultation", false);
        boolean isSCSelected = intent.getBooleanExtra("Specialist Consultation", false);
        boolean isDLSelected = intent.getBooleanExtra("Diagnostic and Lab Test Scheduling", false);

        // Update checkboxes
        checkBox1.setChecked(isGCSelected);
        checkBox2.setChecked(isSCSelected);
        checkBox3.setChecked(isDLSelected);

        // Update selectedServices list and total price
        updateService("General Consultation", isGCSelected, 25);
        updateService("Specialist Consultation", isSCSelected, 50);
        updateService("Diagnostic and Lab Test Scheduling", isDLSelected, 30);

        ImageView backButton = findViewById(R.id.imgBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ImageView homeButton = findViewById(R.id.imgHome);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(BookingActivity.this, HomeActivity.class);
                homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(homeIntent);
                finish();
            }
        });

        // Places API initialized
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyCNRn9Cm3zz1yhBNBgI9kLNDDLVWuHU7qw");
        }

        setupPlacesAutocomplete();

        // Map fragment initialized
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Location client Initialized
        locationClient = LocationServices.getFusedLocationProviderClient(this);

        // UI Initialized
        setupUIComponents();
    }

    private void setupPlacesAutocomplete() {
        PlacesClient placesClient = Places.createClient(this);
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                updateMapLocation(place.getLatLng(), place.getName());
                selectedLocationName = place.getName();
                selectedPlaceId = place.getId();
                selectedLocationText.setText("Selected: " + selectedLocationName + " - " + selectedPlaceId);
            }

            @Override
            public void onError(@NonNull Status status) {
                Log.i("PlacesAPI Error", "An error occurred: " + status);
            }
        });
    }

    private void updateMapLocation(LatLng latLng, String placeName) {
        if (latLng != null) {
            pMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12));
            pMap.addMarker(new MarkerOptions().position(latLng).title(placeName));
        }
    }

    private void setupUIComponents() {
        checkBox1 = findViewById(R.id.checkBox1);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);
        calView = findViewById(R.id.calView);
        tslotView = findViewById(R.id.timeslotRecycler);
        confirmBtn = findViewById(R.id.confirmButton);
        selectedLocationText = findViewById(R.id.selectedLocationText);
        totalPriceTextView = findViewById(R.id.labelPrice);

        checkBox1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            updateService("General Consultation", isChecked, 25);
        });

        checkBox2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            updateService("Specialist Consultation", isChecked, 50);
        });

        checkBox3.setOnCheckedChangeListener((buttonView, isChecked) -> {
            updateService("Diagnostic and Lab Test Scheduling", isChecked, 30);
        });
        setupCalendarView();
        setupTimeSlots();

        confirmBtn.setOnClickListener(v -> {
            if (selectedDate == null || selectedTimeSlot == null || selectedLocationName == null || selectedServices.isEmpty()) {
                Toast.makeText(BookingActivity.this, "Please select all options before confirming.", Toast.LENGTH_LONG).show();
            } else {
                proceedToConfirmation();
            }
        });
    }

    private void updateService(String service, boolean add, int price) {
        if (add && !selectedServices.contains(service)) {
            selectedServices.add(service);
            totalPrice += price;
        } else if (!add && selectedServices.contains(service)) {
            selectedServices.remove(service);
            totalPrice -= price;
        }
        totalPriceTextView.setText("$" + totalPrice); // Update the text view with the new total price
    }

    private void proceedToConfirmation() {

        Intent confirmIntent = new Intent(BookingActivity.this, ConfirmationActivity.class);
        confirmIntent.putStringArrayListExtra("services", new ArrayList<>(selectedServices));
        confirmIntent.putExtra("location", selectedLocationName);
        confirmIntent.putExtra("date", selectedDate);
        confirmIntent.putExtra("time", selectedTimeSlot);
        confirmIntent.putExtra("locationLatLng", selectedLocationLatLng);
        startActivity(confirmIntent);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        pMap = googleMap;
        setupMapSettings();
        enableMyLocation();
    }

    private void setupMapSettings() {
        pMap.getUiSettings().setZoomControlsEnabled(true);
    }

    private void enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            pMap.setMyLocationEnabled(true);
            getLastLocation();
        }
    }
    private void getLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    pMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 12));
                }
            });
        }
    }


    private void setupCalendarView() {
        calView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, dayOfMonth);
            Log.d("Calendar", "Selected date: " + selectedDate);
        });
    }

    private void setupTimeSlots() {
        ArrayList<String> timeSlots = new ArrayList<>();
        timeSlots.add("09:00 AM");
        timeSlots.add("10:00 AM");
        timeSlots.add("11:00 AM");
        timeSlots.add("12:00 PM");
        timeSlots.add("03:00 PM");
        timeSlots.add("04:00 PM");
        timeSlots.add("05:00 PM");
        timeSlots.add("06:00 PM");
        timeSlots.add("07:00 PM");
        timeSlots.add("08:00 PM");

        TimeSlotAdapter adapter = new TimeSlotAdapter(timeSlots, new TimeSlotAdapter.OnTimeSlotClickListener() {
            @Override
            public void onTimeSlotClick(String timeSlot, int position) {
                selectedTimeSlot = timeSlot;
            }
        });
        tslotView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        tslotView.setAdapter(adapter);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}