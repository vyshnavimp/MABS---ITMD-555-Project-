package com.example.mabs;

import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class ConfirmationActivity extends AppCompatActivity implements OnMapReadyCallback {

    private ArrayList<String> servicesList;
    private String datePicked;
    private String timeSlotPicked;
    private String locationName;
    private LatLng locationLatLng;

    private GoogleMap pMap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        ImageView backButton = findViewById(R.id.imgBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ImageView homeButton = findViewById(R.id.imgHome);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(ConfirmationActivity.this, HomeActivity.class);
                homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(homeIntent);
                finish();
            }
        });

        TextView tvConfirmationMessage = findViewById(R.id.tvConfirmationMessage);
        TextView tvAppointmentDetails = findViewById(R.id.tvAppointmentDetails);
        Button btnAddToCalendar = findViewById(R.id.btnAddToCalendar);
        Button btnCancel = findViewById(R.id.btnCancel);
        TextView tvService = findViewById(R.id.tvService);
        TextView tvCalendar = findViewById(R.id.tvCalendar);
        TextView tvLocation = findViewById(R.id.tvLocation);

        // Retrieval of data from the intent
        Intent intent = getIntent();
        servicesList = intent.getStringArrayListExtra("services");
        datePicked = intent.getStringExtra("date");
        timeSlotPicked = intent.getStringExtra("time");
        locationName = intent.getStringExtra("location");
        locationLatLng = intent.getParcelableExtra("locationLatLng");
        Log.d("ConfirmationActivity", "Received LatLng: " + locationLatLng);

        updateMapWithMarker();

        // null or empty list handling
        String serviceList = servicesList == null || servicesList.isEmpty()
                ? "No services selected"
                : TextUtils.join(", ", servicesList);


        String confirmationMessage = "Your appointment for the following services is confirmed and approved: " + serviceList;
        tvConfirmationMessage.setText(confirmationMessage);

        String appointmentDetails = serviceList + " at " + timeSlotPicked + " on " + datePicked + " at " + locationName;
        tvAppointmentDetails.setText(appointmentDetails);

        tvService.setText(serviceList);
        tvCalendar.setText(datePicked + " " + timeSlotPicked);
        tvLocation.setText(locationName);


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        btnAddToCalendar.setOnClickListener(v -> addToCalendar(datePicked, timeSlotPicked, locationName, serviceList));
        btnCancel.setOnClickListener(v -> finish());
    }


    private void addToCalendar(String date, String time, String location, String service) {
        Calendar beginTime = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault());
        try {
            Date startDate = dateFormat.parse(date + " " + time);
            beginTime.setTime(startDate);
        } catch (ParseException e) {
            Toast.makeText(this, "Error parsing date/time", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return;
        }
        Calendar endTime = (Calendar) beginTime.clone();
        endTime.add(Calendar.HOUR, 1);

        Intent intent = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginTime.getTimeInMillis())
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endTime.getTimeInMillis())
                .putExtra(CalendarContract.Events.TITLE, service + " Appointment")
                .putExtra(CalendarContract.Events.DESCRIPTION, service + " appointment at " + location)
                .putExtra(CalendarContract.Events.EVENT_LOCATION, location)
                .putExtra(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_BUSY);
        startActivity(intent);
    }

    private void updateMapWithMarker() {
        Log.d("ConfirmationActivity", "Updating Map Marker: " + locationLatLng);
        if (pMap != null && locationLatLng != null) {
            pMap.clear(); // Clears any existing markers on the map
            pMap.addMarker(new MarkerOptions().position(locationLatLng).title(locationName));
            pMap.moveCamera(CameraUpdateFactory.newLatLngZoom(locationLatLng, 15));
        } else {
            Log.d("ConfirmationActivity", "Map or LatLng is null");
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        pMap = googleMap;
        Log.d("ConfirmationActivity", "Map is ready. LatLng: " + locationLatLng);
        updateMapWithMarker();
    }



}



