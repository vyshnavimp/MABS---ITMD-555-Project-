package com.example.mabs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class EventAdapter extends ArrayAdapter<Event> {
    private List<Event> events;

    public EventAdapter(Context context, List<Event> events) {
        super(context, R.layout.item_event, events);
        this.events = events;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            // Inflate the layout for each item
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_event, parent, false);
            holder = new ViewHolder();
            // Set up to contain the views
            holder.title = convertView.findViewById(R.id.tvEventTitle);
            holder.timeRange = convertView.findViewById(R.id.tvEventTimeRange);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        Event event = getItem(position);


        if (event != null) {
            holder.title.setText(event.getTitle());
            holder.timeRange.setText(event.getTimeRange());
        }


        return convertView;
    }


    static class ViewHolder {
        TextView title;
        TextView timeRange;
    }
}