package com.example.mabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private ViewPager2 viewPagerImages;
    private final Handler sliderHandler = new Handler();
    private final List<Integer> imageList = new ArrayList<>();
    private final long SLIDE_DELAY_MS = 3000; // milliseconds

    // sliding images
    private final Runnable slideRunnable = new Runnable() {
        @Override
        public void run() {
            int currentItem = viewPagerImages.getCurrentItem();
            int totalItems = imageList.size();
            if (viewPagerImages != null && totalItems > 0) {
                viewPagerImages.setCurrentItem((currentItem + 1) % totalItems, true);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // image list
        imageList.add(R.drawable.vp1);
        imageList.add(R.drawable.vp2);
        imageList.add(R.drawable.vp3);

        // ViewPager2
        viewPagerImages = findViewById(R.id.viewPagerImages);
        PictureAdapter pictureAdapter = new PictureAdapter(this, imageList);
        viewPagerImages.setAdapter(pictureAdapter);


        startImageSlider();


        setupCardClickListeners();
    }

    private void startImageSlider() {

        sliderHandler.removeCallbacks(slideRunnable);

        sliderHandler.postDelayed(slideRunnable, SLIDE_DELAY_MS);
    }

    private void setupCardClickListeners() {

        findViewById(R.id.cardWalk).setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, ReminderActivity.class);
                startActivity(intent);
            });


            findViewById(R.id.cardGrooming).setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, ServicesActivity.class);
                startActivity(intent);

            });

            findViewById(R.id.cardPetCare).setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, QuickCareActivity.class);
                startActivity(intent);
            });

            findViewById(R.id.cardDayCare).setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, InpatientActivity.class);
                startActivity(intent);
            });


            findViewById(R.id.cardAbout).setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, AboutActivity.class);
                startActivity(intent);
            });


        findViewById(R.id.cardProfile).setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
            startActivity(intent);
        });
        }

    @Override
    protected void onPause() {
        super.onPause();

        sliderHandler.removeCallbacks(slideRunnable);
    }

    @Override
    protected void onResume() {
        super.onResume();

        startImageSlider();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        sliderHandler.removeCallbacksAndMessages(null);
    }
}
