package com.example.mabs;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Locale;

public class InpatientActivity extends AppCompatActivity implements OnMapReadyCallback {

    private Button fourHBtn, eightHBtn, twelveHBtn, twentyFourHBtn, bookBtn;
    private TextView priceTV, selectedLocationText;
    private CalendarView calView;
    private GoogleMap pMap;
    private FusedLocationProviderClient locationClient;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 101;
    private static final String TAG = "InpatientActivity";

    private double Price;
    private int hoursPicked;
    private String datePicked;
    private String locationName;
    private LatLng selectedLocationLatLng;

    private String placeId;

    private SupportMapFragment mapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inpatient);

        ImageView backButton = findViewById(R.id.imgBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ImageView homeButton = findViewById(R.id.imgHome);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(InpatientActivity.this, HomeActivity.class);
                homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(homeIntent);
                finish();
            }
        });

        // Places API.
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), getString(R.string.google_maps_key));
        }

        // Initialize map fragment.
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Initialize location client.
        locationClient = LocationServices.getFusedLocationProviderClient(this);

        // Initialize UI components.
        calView = findViewById(R.id.calendarView);
        priceTV = findViewById(R.id.priceTextView);
        selectedLocationText = findViewById(R.id.selectedLocationText);
        fourHBtn = findViewById(R.id.fourHoursButton);
        eightHBtn = findViewById(R.id.eightHoursButton);
        twelveHBtn = findViewById(R.id.twelveHoursButton);
        twentyFourHBtn = findViewById(R.id.twentyFourHoursButton);
        bookBtn = findViewById(R.id.confirmButton);

        setupCalendarView();
        setupDurationButtons();
        setupPlacesAutocomplete();

        bookBtn.setOnClickListener(v -> proceedToConfirmation());
    }

    private void setupPlacesAutocomplete() {
        PlacesClient placesClient = Places.createClient(this);
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                updateMapLocation(place.getLatLng(), place.getName());
                locationName = place.getName();
                placeId = place.getId();
                selectedLocationText.setText("Selected: " + locationName + " - " + placeId);
            }

            @Override
            public void onError(@NonNull Status status) {
                Log.i("PlacesAPI Error", "An error occurred: " + status);
            }
        });
    }

    private void updateMapLocation(LatLng latLng, String placeName) {
        if (latLng != null) {
            pMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12));
            pMap.addMarker(new MarkerOptions().position(latLng).title(placeName));
        }
    }
    private void setupCalendarView() {
        calView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar cal = Calendar.getInstance();
            cal.set(year, month, dayOfMonth);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            datePicked = dateFormat.format(cal.getTime());
        });
    }

    private void setupDurationButtons() {
        fourHBtn.setOnClickListener(v -> updatePrice(4)); // $50 for 4 hours
        eightHBtn.setOnClickListener(v -> updatePrice(8)); // $100 for 8 hours
        twelveHBtn.setOnClickListener(v -> updatePrice(12)); // $150 for 12 hours
        twentyFourHBtn.setOnClickListener(v -> updatePrice(24)); // $200 for 24 hours
    }

    private void updatePrice(int hours) {
        double basePrice = 50;
        double price = basePrice;

        if (hours > 4) {
            int additionalBlocks = (hours - 4) / 4;
            for (int i = 0; i < additionalBlocks; i++) {
                price += basePrice;
            }
        }

        Price = price;
        hoursPicked = hours;
        priceTV.setText(String.format(Locale.getDefault(), "Total Cost: $%.2f for %d hours", Price, hoursPicked));
    }


    private void proceedToConfirmation() {
        Intent confirmIntent = new Intent(InpatientActivity.this, InpatientConfirmationActivity.class);
        confirmIntent.putExtra("selectedPrice", Price);
        confirmIntent.putExtra("selectedHours", hoursPicked);
        confirmIntent.putExtra("selectedDate", datePicked);
        confirmIntent.putExtra("selectedLocationName", locationName);
        confirmIntent.putExtra("selectedLocationLatLng", selectedLocationLatLng);
        startActivity(confirmIntent);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        pMap = googleMap;
        enableMyLocation();
    }

    private void enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }
        pMap.setMyLocationEnabled(true);
        getLastLocation();
    }

    private void getLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    pMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15));
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            enableMyLocation();
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}
