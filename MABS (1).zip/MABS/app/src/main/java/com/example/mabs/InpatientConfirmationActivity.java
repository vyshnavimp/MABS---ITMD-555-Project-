package com.example.mabs;

import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Calendar;

public class InpatientConfirmationActivity extends AppCompatActivity implements OnMapReadyCallback {

    private String locationName;
    private LatLng locationLatLng;
    private GoogleMap pMap;
    private double Price;
    private int hoursPicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ipconfirm);

        TextView tvConfirmationMessage = findViewById(R.id.tvConfirmationMessage);
        TextView tvPrice = findViewById(R.id.tvPrice);
        TextView tvDuration = findViewById(R.id.tvHours);
        TextView tvLocation = findViewById(R.id.tvLocation);
        Button btnCancel = findViewById(R.id.btnCancel);
        Button btnAddToSchedule = findViewById(R.id.btnAddToCalendar);

        ImageView backButton = findViewById(R.id.imgBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ImageView homeButton = findViewById(R.id.imgHome);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(InpatientConfirmationActivity.this, HomeActivity.class);
                homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(homeIntent);
                finish();
            }
        });


        Intent intent = getIntent();
        locationName = intent.getStringExtra("selectedLocationName");
        locationLatLng = intent.getParcelableExtra("selectedLocationLatLng");
        Price = intent.getDoubleExtra("selectedPrice", 0); // Make sure the key matches
        hoursPicked = intent.getIntExtra("selectedHours", 0); // Make sure the key matches



        tvConfirmationMessage.setText("InPatient Room booking at " + locationName + " is confirmed!");
        tvPrice.setText(String.format("Total Cost: $%.2f", Price));
        tvDuration.setText(String.format("Duration: %d hours", hoursPicked));
        tvLocation.setText(locationName);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }


        btnAddToSchedule.setOnClickListener(v -> addToCalendar());


        btnCancel.setOnClickListener(v -> finish());
    }

    private void addToCalendar() {
        Calendar beginTime = Calendar.getInstance();
        beginTime.setTimeInMillis(System.currentTimeMillis());


        beginTime.add(Calendar.HOUR_OF_DAY, 2);

        Calendar endTime = (Calendar) beginTime.clone();
        endTime.add(Calendar.HOUR_OF_DAY, hoursPicked);

        Intent intent = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginTime.getTimeInMillis())
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endTime.getTimeInMillis())
                .putExtra(CalendarContract.Events.TITLE, "InPatient Room Booking")
                .putExtra(CalendarContract.Events.DESCRIPTION, "InPatient Room booked for " + hoursPicked + " hours.")
                .putExtra(CalendarContract.Events.EVENT_LOCATION, locationName)
                .putExtra(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_BUSY);

        startActivity(intent);
    }


    private void updateMapWithMarker() {
        if (pMap != null && locationLatLng != null) {
            pMap.clear();
            pMap.addMarker(new MarkerOptions().position(locationLatLng).title(locationName));
            pMap.moveCamera(CameraUpdateFactory.newLatLngZoom(locationLatLng, 15));
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        pMap = googleMap;
        updateMapWithMarker();
    }
}
