
package com.example.mabs;

public class PatientProfile {
    private String patientName;
    private String medicalRecordNumber;
    private String age;
    private String primaryPhysician;
    private String insuranceProvider;
    private String allergies;
    private String specialNotes;
    private String profileImageUrl;

    public PatientProfile() { }

    public PatientProfile(
            String patientName,
            String medicalRecordNumber,
            String age,
            String primaryPhysician,
            String insuranceProvider,
            String allergies,
            String specialNotes,
            String profileImageUrl
    ) {
        this.patientName = patientName;
        this.medicalRecordNumber = medicalRecordNumber;
        this.age = age;
        this.primaryPhysician = primaryPhysician;
        this.insuranceProvider = insuranceProvider;
        this.allergies = allergies;
        this.specialNotes = specialNotes;
        this.profileImageUrl = profileImageUrl;
    }

    public String getPatientName() { return patientName; }
    public void setPatientName(String v) { patientName = v; }

    public String getMedicalRecordNumber() { return medicalRecordNumber; }
    public void setMedicalRecordNumber(String v) { medicalRecordNumber = v; }

    public String getAge() { return age; }
    public void setAge(String v) { age = v; }

    public String getPrimaryPhysician() { return primaryPhysician; }
    public void setPrimaryPhysician(String v) { primaryPhysician = v; }

    public String getInsuranceProvider() { return insuranceProvider; }
    public void setInsuranceProvider(String v) { insuranceProvider = v; }

    public String getAllergies() { return allergies; }
    public void setAllergies(String v) { allergies = v; }

    public String getSpecialNotes() { return specialNotes; }
    public void setSpecialNotes(String v) { specialNotes = v; }

    public String getProfileImageUrl() { return profileImageUrl; }
    public void setProfileImageUrl(String v) { profileImageUrl = v; }
}
