package com.example.mabs;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    private static final String USERS_COLLECTION = "users";

    private ImageView imgHome, imgLogout;
    private CircleImageView imgProfilePicture;
    private EditText editPatientName, editMedicalRecordNumber, editAge,
            editPrimaryPhysician, editInsuranceProvider,
            editAllergies, editSpecialNotes;
    private Button btnEdit, btnConfirm;

    private Uri selectedImageUri;
    private PatientProfile profile;

    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private StorageReference storageRef;
    private ActivityResultLauncher<Intent> pickImageLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        auth       = FirebaseAuth.getInstance();
        db         = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference("profile_pics");

        imgHome             = findViewById(R.id.imgHome);
        imgLogout           = findViewById(R.id.imgLogout);
        imgProfilePicture   = findViewById(R.id.imgProfilePicture);
        editPatientName     = findViewById(R.id.editPatientName);
        editMedicalRecordNumber = findViewById(R.id.editMedicalRecordNumber);
        editAge             = findViewById(R.id.editAge);
        editPrimaryPhysician= findViewById(R.id.editPrimaryPhysician);
        editInsuranceProvider = findViewById(R.id.editInsuranceProvider);
        editAllergies       = findViewById(R.id.editAllergies);
        editSpecialNotes    = findViewById(R.id.editSpecialNotes);
        btnEdit             = findViewById(R.id.btnEdit);
        btnConfirm          = findViewById(R.id.btnConfirm);

        pickImageLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        selectedImageUri = result.getData().getData();
                        Glide.with(this).load(selectedImageUri).into(imgProfilePicture);
                    }
                }
        );
        imgProfilePicture.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
            pick.setType("image/*");
            pickImageLauncher.launch(pick);
        });

        imgHome.setOnClickListener(v -> finish());

        imgLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Confirm Logout")
                    .setMessage("Are you sure you want to log out?")
                    .setPositiveButton("Yes", (d, w) -> {
                        auth.signOut();
                        startActivity(new Intent(this, SignInActivity.class)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        btnEdit.setOnClickListener(v -> setEditingEnabled(true));
        btnConfirm.setOnClickListener(v -> {
            setEditingEnabled(false);
            saveProfileToFirebase(() ->
                    Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show()
            );
        });

        setEditingEnabled(false);
        loadProfileFromFirebase();
    }

    private void setEditingEnabled(boolean enabled) {
        editPatientName.setEnabled(enabled);
        editMedicalRecordNumber.setEnabled(enabled);
        editAge.setEnabled(enabled);
        editPrimaryPhysician.setEnabled(enabled);
        editInsuranceProvider.setEnabled(enabled);
        editAllergies.setEnabled(enabled);
        editSpecialNotes.setEnabled(enabled);
        btnConfirm.setVisibility(enabled ? View.VISIBLE : View.GONE);
    }

    private void loadProfileFromFirebase() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        String uid = user.getUid();
        Log.d("PROFILE", "Current UID: " + uid);

        db.collection(USERS_COLLECTION)
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        profile = doc.toObject(PatientProfile.class);
                        populateUI();
                    }
                })
                .addOnFailureListener(e ->
                        Log.e("PROFILE", "Error loading profile", e)
                );
    }

    private void populateUI() {
        if (profile == null) return;
        editPatientName.setText(profile.getPatientName());
        editMedicalRecordNumber.setText(profile.getMedicalRecordNumber());
        editAge.setText(profile.getAge());
        editPrimaryPhysician.setText(profile.getPrimaryPhysician());
        editInsuranceProvider.setText(profile.getInsuranceProvider());
        editAllergies.setText(profile.getAllergies());
        editSpecialNotes.setText(profile.getSpecialNotes());
        String url = profile.getProfileImageUrl();
        if (url != null && !url.isEmpty()) {
            Glide.with(this).load(url).into(imgProfilePicture);
        }
    }

    private void saveProfileToFirebase(Runnable onSuccess) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        String uid = user.getUid();
        profile = new PatientProfile(
                editPatientName.getText().toString().trim(),
                editMedicalRecordNumber.getText().toString().trim(),
                editAge.getText().toString().trim(),
                editPrimaryPhysician.getText().toString().trim(),
                editInsuranceProvider.getText().toString().trim(),
                editAllergies.getText().toString().trim(),
                editSpecialNotes.getText().toString().trim(),
                profile != null ? profile.getProfileImageUrl() : ""
        );

        ProgressDialog pd = ProgressDialog.show(this, "Saving", "Please wait...", true);

        Runnable writeProfile = () ->
                db.collection(USERS_COLLECTION)
                        .document(uid)
                        .set(profile, SetOptions.merge())
                        .addOnSuccessListener(a -> {
                            pd.dismiss();
                            onSuccess.run();
                        })
                        .addOnFailureListener(e -> {
                            pd.dismiss();
                            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        });

        if (selectedImageUri != null) {
            StorageReference picRef = storageRef.child(uid + ".jpg");
            picRef.putFile(selectedImageUri)
                    .addOnSuccessListener(task -> picRef.getDownloadUrl()
                            .addOnSuccessListener(uri -> {
                                profile.setProfileImageUrl(uri.toString());
                                writeProfile.run();
                            })
                            .addOnFailureListener(e -> {
                                pd.dismiss();
                                Toast.makeText(this, "URL fetch failed", Toast.LENGTH_SHORT).show();
                            })
                    )
                    .addOnFailureListener(e -> {
                        pd.dismiss();
                        Toast.makeText(this, "Image upload failed", Toast.LENGTH_SHORT).show();
                    });
        } else {
            writeProfile.run();
        }
    }
}
