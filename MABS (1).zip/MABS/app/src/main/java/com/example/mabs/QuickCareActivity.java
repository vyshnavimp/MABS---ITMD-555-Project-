package com.example.mabs;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;



public class QuickCareActivity extends AppCompatActivity implements OnMapReadyCallback {

    CheckBox checkBoxPR;
    CheckBox checkBoxMA;

    private List<String> selectedServices = new ArrayList<>();
    private CalendarView calView;
    private RecyclerView timeslotRV;
    private Button confirmBtn;
    private GoogleMap pMap;
    private TextView selectedLocationText;
    private SupportMapFragment mapFragment;
    private FusedLocationProviderClient locationClient;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 101;
    private static final String TAG = "QuickCareActivity";

    private String datePicked;

    private String timeslotPicked;

    private String selectedLocationName;
    private String PlaceId;

    private String selectedType;

    private LatLng selectedLocationLatLng;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quickcare);

        ImageView backButton = findViewById(R.id.imgBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ImageView homeButton = findViewById(R.id.imgHome);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(QuickCareActivity.this, HomeActivity.class);
                homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(homeIntent);
                finish();
            }
        });

        // Places API.
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyCNRn9Cm3zz1yhBNBgI9kLNDDLVWuHU7qw");
        }

        // Autocomplete Fragment
        setupPlacesAutocomplete();

        // map fragment
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // location client
        locationClient = LocationServices.getFusedLocationProviderClient(this);

        // Initialize UI components
        setupUIComponents();
    }

    private void setupPlacesAutocomplete() {
        PlacesClient placesClient = Places.createClient(this);
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                updateMapLocation(place.getLatLng(), place.getName());
                selectedLocationName = place.getName();
                PlaceId = place.getId();
                selectedLocationText.setText("Selected: " + selectedLocationName + " - " + PlaceId);
            }

            @Override
            public void onError(@NonNull Status status) {
                Log.i("PlacesAPI Error", "An error occurred: " + status);
            }
        });
    }

    private void updateMapLocation(LatLng latLng, String placeName) {
        if (latLng != null) {
            pMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12));
            pMap.addMarker(new MarkerOptions().position(latLng).title(placeName));
        }
    }

    private void setupUIComponents() {
        checkBoxPR = findViewById(R.id.checkBoxOP);
        checkBoxMA= findViewById(R.id.checkBoxSurgery);

        calView = findViewById(R.id.calendarView);
        timeslotRV = findViewById(R.id.timeslotRecyclerView);
        confirmBtn = findViewById(R.id.confirmButton);
        selectedLocationText = findViewById(R.id.selectedLocationText);

        setupCheckBoxes();;
        setupCalendarView();
        setupTimeSlots();

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When confirm button is clicked
                if (datePicked == null || timeslotPicked == null || selectedLocationName == null) {
                    // If any of the selections are null, notify the user to make a selection
                    Toast.makeText(QuickCareActivity.this, "Please select a date, time slot, and location.", Toast.LENGTH_LONG).show();
                } else {
                    proceedToConfirmation();
                }
            }
        });
    }

    private void proceedToConfirmation() {
        ArrayList<String> servicesList = new ArrayList<>(selectedServices); // Make sure it's ArrayList
        Intent confirmIntent = new Intent(QuickCareActivity.this, ConfirmationActivity.class);
        confirmIntent.putStringArrayListExtra("services", servicesList); // Correct method to use
        confirmIntent.putExtra("location", selectedLocationName);
        confirmIntent.putExtra("date", datePicked);
        confirmIntent.putExtra("time", timeslotPicked);
        confirmIntent.putExtra("locationLatLng", selectedLocationLatLng);
        startActivity(confirmIntent);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        pMap = googleMap;
        setupMapSettings();
        enableMyLocation();
    }

    private void setupMapSettings() {
        pMap.getUiSettings().setZoomControlsEnabled(true);
    }

    private void enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            pMap.setMyLocationEnabled(true);
            getLastLocation();
        }
    }


    private void getLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    pMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 12));
                }
            });
        }
    }

    private void fetchNearbyPlaces(LatLng location) {
        String types = "veterinary_care|pet_care|pet_hospital";
        int radius = 50000; // 50 km radius
        String apiKey = "AIzaSyCNRn9Cm3zz1yhBNBgI9kLNDDLVWuHU7qw"; // Use your actual API key
        String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json" +
                "?location=" + location.latitude + "," + location.longitude +
                "&radius=" + radius +
                "&type=" + types +
                "&key=" + apiKey;

        new FetchPlacesTask().execute(url);
    }

    private class FetchPlacesTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            try {
                return downloadUrl(urls[0]);
            } catch (Exception e) {
                Log.e("Background Task", e.toString());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                parseLocations(result);
            } catch (JSONException e) {
                Log.e("JSON Parser", "Error parsing data " + e.toString());
            }
        }

        private void parseLocations(String json) throws JSONException {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray resultsArray = jsonObject.getJSONArray("results");

            for (int i = 0; i < resultsArray.length(); i++) {
                JSONObject place = resultsArray.getJSONObject(i);
                JSONObject location = place.getJSONObject("geometry").getJSONObject("location");
                LatLng latLng = new LatLng(location.getDouble("lat"), location.getDouble("lng"));
                String placeName = place.getString("name");

                pMap.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title(placeName)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
            }

            if (resultsArray.length() == 0) {
                Log.d(TAG, "No places found.");
                Toast.makeText(QuickCareActivity.this, "No pet-related places found nearby.", Toast.LENGTH_LONG).show();
            }
        }

        private String downloadUrl(String strUrl) throws IOException {
            InputStream iStream = null;
            HttpURLConnection urlConnection = null;
            StringBuilder sb = new StringBuilder();
            try {
                URL url = new URL(strUrl);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();
                iStream = urlConnection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
            } catch (Exception e) {
                Log.e("Exception", e.toString());
            } finally {
                if (iStream != null) {
                    iStream.close();
                }
                urlConnection.disconnect();
            }
            return sb.toString();
        }
    }

    private void setupCheckBoxes() {
        // References to CheckBoxes in your layout
        checkBoxPR = findViewById(R.id.checkBoxOP);
        checkBoxMA = findViewById(R.id.checkBoxSurgery);


        checkBoxPR.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                selectedServices.add("Prescription Refill");
            } else {
                selectedServices.remove("Minor Ailments");
            }
        });


        checkBoxMA.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                selectedServices.add("Minor Ailments");
            } else {
                selectedServices.remove("Minor Ailments");
            }
        });
    }


    private void setupCalendarView() {
        calView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            datePicked = String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, dayOfMonth);
            Log.d("Calendar", "Selected date: " + datePicked);
        });
    }

    private void setupTimeSlots() {
        ArrayList<String> timeSlots = new ArrayList<>();
        timeSlots.add("09:00 AM");
        timeSlots.add("10:00 AM");
        timeSlots.add("11:00 AM");
        timeSlots.add("12:00 PM");
        timeSlots.add("03:00 PM");
        timeSlots.add("04:00 PM");
        timeSlots.add("05:00 PM");
        timeSlots.add("06:00 PM");
        timeSlots.add("07:00 PM");
        timeSlots.add("08:00 PM");

        TimeSlotAdapter adapter = new TimeSlotAdapter(timeSlots, new TimeSlotAdapter.OnTimeSlotClickListener() {
            @Override
            public void onTimeSlotClick(String timeSlot, int position) {
                timeslotPicked = timeSlot;
            }
        });
        timeslotRV.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        timeslotRV.setAdapter(adapter);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
