package com.example.mabs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class ServicesActivity extends AppCompatActivity {

    private ImageView groomCheckmark, nailCheckmark, bathCheckmark;
    private boolean isGCSelected = false, isSCSelected = false, isDLSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.services_screen);

        // Initialize checkmark views
        groomCheckmark = findViewById(R.id.checkmark_groom);
        nailCheckmark = findViewById(R.id.checkmark_nail);
        bathCheckmark = findViewById(R.id.checkmark_bath);

        // click listeners for the service cards
        setupServiceSelection();

        // Setup navigation buttons
        setupNavigationButtons();
    }

    private void setupServiceSelection() {
        findViewById(R.id.groomCard).setOnClickListener(v -> {
            isGCSelected = !isGCSelected;
            toggleCheckmark(groomCheckmark, isGCSelected);
        });

        findViewById(R.id.nailClipCard).setOnClickListener(v -> {
            isSCSelected = !isSCSelected;
            toggleCheckmark(nailCheckmark, isSCSelected);
        });

        findViewById(R.id.bathCard).setOnClickListener(v -> {
            isDLSelected = !isDLSelected;
            toggleCheckmark(bathCheckmark, isDLSelected);
        });

        findViewById(R.id.button_book_appointment).setOnClickListener(v -> {
            Intent intent = new Intent(ServicesActivity.this, BookingActivity.class);
            intent.putExtra("General Consultation", isGCSelected);
            intent.putExtra("Specialist Consultation", isSCSelected);
            intent.putExtra("Diagnostic and Lab Test Scheduling", isDLSelected);
            startActivity(intent);
        });
    }

    private void toggleCheckmark(ImageView checkmark, boolean isSelected) {
        if (isSelected) {
            checkmark.setVisibility(View.VISIBLE); // Show the checkmark on selection
        } else {
            checkmark.setVisibility(View.GONE); // Hide the checkmark on deselection
        }
    }

    private void setupNavigationButtons() {
        findViewById(R.id.imgBack).setOnClickListener(v -> finish());

        findViewById(R.id.imgHome).setOnClickListener(v -> {
            Intent homeIntent = new Intent(ServicesActivity.this, HomeActivity.class);
            homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(homeIntent);
            finish();
        });
    }
}
