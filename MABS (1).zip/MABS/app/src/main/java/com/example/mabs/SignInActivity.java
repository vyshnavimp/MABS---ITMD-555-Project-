package com.example.mabs;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class SignInActivity extends AppCompatActivity {

    private EditText emailID;
    private EditText passwordP;
    private Button signInBtn;
    private TextView signUp;
    private TextView forgotPassword;
    private FirebaseAuth pAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        // Initialize Firebase Auth
        pAuth = FirebaseAuth.getInstance();


        emailID = findViewById(R.id.emailEditText);
        passwordP = findViewById(R.id.loginPasswordEditText);
        signInBtn = findViewById(R.id.loginButton);
        signUp = findViewById(R.id.textViewSignUp);
        forgotPassword = findViewById(R.id.forgotPasswordText);

        // click listeners
        signInBtn.setOnClickListener(view -> attemptSignIn());
        signUp.setOnClickListener(view -> gotoSignUp());
        forgotPassword.setOnClickListener(view -> sendResetEmail());

        if (getIntent().hasExtra("email")) {
            String email = getIntent().getStringExtra("email");
            emailID.setText(email);
        }

    }

    // Add this onStart() method
    @Override
    protected void onStart() {
        super.onStart();

        // Check if user is signed in (non-null) and update UI accordingly.
        if (pAuth.getCurrentUser() != null) {
            gotoHome();
        }
    }

    private void attemptSignIn() {
        String email = emailID.getText().toString();
        String password = passwordP.getText().toString();

        if (validateEntries(email, password)) {
            pAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            gotoHome();
                        } else {
                            displayToast("Authentication failed: " + task.getException().getMessage());
                        }
                    });
        }
    }

    private boolean validateEntries(String email, String password) {
        if (email.isEmpty()) {
            displayToast("Email cannot be empty.");
            return false;
        }
        if (password.isEmpty()) {
            displayToast("Password cannot be empty.");
            return false;
        }
        return true;
    }

    private void gotoHome() {
        Intent intent = new Intent(SignInActivity.this, HomeActivity.class);
        startActivity(intent);
        finish(); // Close the SignInActivity

    }

    private void gotoSignUp() {
        Intent intent = new Intent(SignInActivity.this, SignUpActivity.class);
        startActivity(intent);
    }

    private void sendResetEmail() {
        String emailAddress = emailID.getText().toString();

        if (!emailAddress.isEmpty()) {
            pAuth.sendPasswordResetEmail(emailAddress)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            displayToast("Password reset email sent.");
                        } else {
                            displayToast("Failed to send reset email. " + task.getException().getMessage());
                        }
                    });
        } else {
            displayToast("Please enter your email address to reset the password.");
        }
    }

    private void displayToast(String message) {
        Toast.makeText(SignInActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
