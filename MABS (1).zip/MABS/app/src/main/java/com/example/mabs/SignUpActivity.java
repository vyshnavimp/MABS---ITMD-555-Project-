package com.example.mabs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {

    private EditText emailID, passwordP, confirmPasswordP;
    private Button signUpBtn;
    private FirebaseAuth pAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_screen);

        ImageView backButton = findViewById(R.id.imgBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Initialize Firebase Auth
        pAuth = FirebaseAuth.getInstance();

        emailID = findViewById(R.id.emailEditText);
        passwordP = findViewById(R.id.passwordEditText);
        confirmPasswordP = findViewById(R.id.repeatPasswordEditText);
        signUpBtn = findViewById(R.id.signUpButton);

        signUpBtn.setOnClickListener(view -> registerUser());
    }


    private void registerUser() {
        String email = emailID.getText().toString().trim();
        String password = passwordP.getText().toString().trim();
        String confirmPassword = confirmPasswordP.getText().toString().trim();

        // Input validation
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Email and password fields cannot be empty.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Firebase registration
        pAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(SignUpActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();

                        // Navigate back to SignInActivity and pass the email
                        Intent intent = new Intent(SignUpActivity.this, SignInActivity.class);
                        intent.putExtra("email", email);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(SignUpActivity.this, "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}

